import { componentFactoryName } from '@angular/compiler';
import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  name = 'Angular';
  sectionID: number;
  sectionList = [
    { name: 'What went well', id: 1 },
    { name: 'What can be improved', id: 2 },
    { name: 'Start doing', id: 3 },
    { name: 'Action Items', id: 4 },
  ];

  addCards(sectionId: number) {
    //alert(sectionId);
    this.sectionID = sectionId;
  }
}
