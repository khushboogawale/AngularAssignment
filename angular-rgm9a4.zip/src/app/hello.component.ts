import { Component, Input } from '@angular/core';

@Component({
  selector: 'add-card',
  template: `<h1>Hello {{addCardId}}!</h1>`,
  styles: [`h1 { font-family: Lato; }`],
})
export class HelloComponent {
  @Input() itemId: number;

  addCardId: any;
  ngOnChanges() {
    this.addCardId = this.itemId;
  }
}
